export class Employee {
  empId?: number;
  empName?: string;
  empPhone?: string;
  empEmail?: string;
  empAddress?: string;
}
