export const environment = {
  production: false,
   apiUrl : 'http://task.soft-zone.net/api/Employees'
};
